check_magisk_version() {
  ui_print "- Magisk version: $MAGISK_VER_CODE"
  if [ "$MAGISK_VER_CODE" -lt 26403 ]; then
    ui_print "*********************************************************"
    ui_print "! Please install Magisk v27+"
    abort    "*********************************************************"
  fi
}

require_new_android() {
  ui_print "*********************************************************"
  ui_print "! Unsupported Android version ${1} (below Android 9 Pie)"
  ui_print "! Learn more from our GitHub"
  [ "$BOOTMODE" == "true" ] && am start -a android.intent.action.VIEW -d https://github.com/LSPosed/LSPosed/#supported-versions
  abort    "*********************************************************"
}

check_android_version() {
  if [ "$API" -ge 28 ]; then
    ui_print "- Android SDK version: $API"
  else
    require_new_android "$API"
  fi
}

check_incompatible_module() {
  MODULEDIR="$(magisk --path)/.magisk/modules"
  for id in "riru_dreamland" "riru_edxposed" "riru_edxposed_sandhook" "taichi"; do
    if [ -d "$MODULEDIR/$id" ] && [ ! -f "$MODULEDIR/$id/disable" ] && [ ! -f "$MODULEDIR/$id/remove" ]; then
      ui_print "*********************************************************"
      ui_print "! Please disable or uninstall incompatible frameworks:"
      ui_print "! $id"
      abort    "*********************************************************"
      break
    fi
  done
}

install_lspctl_link() {
  link_path=$1
  link_target="/data/adb/modules/zygisk_lsposed/lspctl"

  if [ -L "$link_path" ]; then
    old_target=$(readlink "$link_path")
    if [ "$old_target" != "$link_target" ]; then
      abort "! Refusing to replace existing lspctl link: $link_path -> $old_target"
    fi
  elif [ -e "$link_path" ]; then
    abort "! Refusing to replace existing path: $link_path"
  fi

  ln -sfn "$link_target" "$link_path" || abort "! Failed to create $link_path"
}
