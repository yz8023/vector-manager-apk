# LSPosed Framework

[![Channel](https://img.shields.io/badge/Follow-Telegram-blue.svg?logo=telegram)](https://t.me/LSPosed) [![Chat](https://img.shields.io/badge/Join-QQ%E9%A2%91%E9%81%93-red?logo=tencent-qq&logoColor=red)](https://qun.qq.com/qqweb/qunpro/share?_wv=3&_wwv=128&inviteCode=Xz9dJ&from=246610&biz=ka) [![Download](https://img.shields.io/github/v/release/LSPosed/LSPosed?color=orange&logoColor=orange&label=Download&logo=DocuSign)](https://github.com/LSPosed/LSPosed/releases/latest) [![Total](https://shields.io/github/downloads/LSPosed/LSPosed/total?logo=Bookmeter&label=Counts&logoColor=yellow&color=yellow)](https://github.com/LSPosed/LSPosed/releases)

## Introduction 

A Zygisk module trying to provide an ART hooking framework which delivers consistent APIs with the OG Xposed, leveraging LSPlant hooking framework.

> Xposed is a framework for modules that can change the behavior of the system and apps without touching any APKs. That's great because it means that modules can work for different versions and even ROMs without any changes (as long as the original code was not changed too much). It's also easy to undo. As all changes are done in the memory, you just need to deactivate the module and reboot to get your original system back. There are many other advantages, but here is just one more: multiple modules can do changes to the same part of the system or app. With modified APKs, you have to choose one. No way to combine them, unless the author builds multiple APKs with different combinations.

## Supported Versions

Android 9 ~ 17

## Install

1. Install root solution and Zygisk
2. [Download](#download) and install LSPosed
3. Reboot
4. Open LSPosed manager from notification
5. Have fun :)

## Download

- For stable releases, please go to [Github Releases page](https://github.com/LSPosed/LSPosed/releases)

## Command line

The CLI program is located in `/data/adb/modules/zygisk_lsposed/lspctl`. After 
installing KernelSU and APatch, the `lspctl` command will be added to the root 
shell's `PATH`. Run `lspctl --help` to see the available commands. Use `--json`
for machine-readable output.

`lspctl` is an interactive debugging tool for humans and AI agents working from
a computer, not a stable control protocol. Its commands, options, output, exit
codes, and daemon communication protocol may change without notice. Do not build
apps or unattended integrations against it.

Every command requires UID 0. Mutation commands are additionally restricted to
root shells originating from ADB; this is a deliberate barrier against rooted
Xposed apps using the supported CLI to rewrite their own scope, not an absolute
security boundary against arbitrary root code.

## For Developers

Developers are welcome to write Xposed modules with hooks based on LSPosed Framework. A module based on LSPosed framework is fully compatible with the original Xposed Framework, and vice versa, a Xposed Framework-based module will work well with LSPosed framework too.

- [Modern Xposed API](https://github.com/LSPosed/LSPosed/wiki/Develop-Xposed-Modules-Using-Modern-Xposed-API)

We use our own module repository. We welcome developers to submit modules to our repository, and then modules can be downloaded in LSPosed.

- [LSPosed Module Repository](https://github.com/Xposed-Modules-Repo)

## Community Discussion

- Telegram: [@LSPosed](https://t.me/s/LSPosed)
- Internal test group: [link](https://t.me/s/LSPosed/287)

## Translation Contributing

You can contribute translation [here](https://github.com/LSPosed/LSPosed_translations).

## Credits 

- [Magisk](https://github.com/topjohnwu/Magisk/): makes all these possible
- [XposedBridge](https://github.com/rovo89/XposedBridge): the OG Xposed framework APIs
- [Dobby](https://github.com/jmpews/Dobby): used for inline hooking
- [LSPlant](https://github.com/LSPosed/LSPlant): the core ART hooking framework
- [EdXposed](https://github.com/ElderDrivers/EdXposed): fork source
- ~[Riru](https://github.com/RikkaApps/Riru): provides a way to inject code into zygote process~
- ~[SandHook](https://github.com/ganyao114/SandHook/): ART hooking framework for SandHook variant~
- ~[YAHFA](https://github.com/rk700/YAHFA): previous ART hooking framework~
- ~[dexmaker](https://github.com/linkedin/dexmaker) and [dalvikdx](https://github.com/JakeWharton/dalvik-dx): to dynamically generate YAHFA hooker classes~
- ~[DexBuilder](https://github.com/LSPosed/DexBuilder): to dynamically generate YAHFA hooker classes~
