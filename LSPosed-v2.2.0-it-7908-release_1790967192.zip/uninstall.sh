MODDIR=${0%/*}
MODSDIR=$(dirname "$MODDIR")

remove_lspctl_link() {
  link_path=$1
  if [ -L "$link_path" ] && [ "$(readlink "$link_path")" = "/data/adb/modules/zygisk_lsposed/lspctl" ]; then
    rm -f "$link_path"
  fi
}

remove_lspctl_link "/data/adb/ksu/bin/lspctl"
remove_lspctl_link "/data/adb/ap/bin/lspctl"

rm -rf /data/adb/lspd
