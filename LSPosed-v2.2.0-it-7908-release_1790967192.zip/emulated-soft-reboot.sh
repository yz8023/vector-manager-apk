MODDIR=${0%/*}

"$MODDIR/lspctl" stop
